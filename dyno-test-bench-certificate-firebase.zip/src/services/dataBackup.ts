import {
  AuditEvent,
  LibraryParameter,
  Product,
  TestBenchOption,
  TestRecord,
  User,
} from '../types';

export interface DatabaseBackupPayload {
  schemaVersion: 1;
  backupId: string;
  createdAt: string;
  application: 'KRA Dyno Test & Quality Certificate System';
  users: User[];
  products: Product[];
  parameterLibrary: LibraryParameter[];
  testRecords: TestRecord[];
  auditLogs: AuditEvent[];
  testBenches: TestBenchOption[];
}

function pad(value: number): string {
  return String(value).padStart(2, '0');
}

export function generateBackupId(date = new Date()): string {
  return `KRA-BKP-${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(
    date.getDate()
  )}-${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`;
}

export function buildDatabaseBackup(input: {
  users: User[];
  products: Product[];
  parameterLibrary: LibraryParameter[];
  testRecords: TestRecord[];
  auditLogs: AuditEvent[];
  testBenches: TestBenchOption[];
}): DatabaseBackupPayload {
  return {
    schemaVersion: 1,
    backupId: generateBackupId(),
    createdAt: new Date().toISOString(),
    application: 'KRA Dyno Test & Quality Certificate System',
    ...input,
  };
}

export function downloadJsonFile(payload: unknown, filename: string): boolean {
  try {
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    return true;
  } catch (error) {
    console.error('JSON download failed:', error);
    return false;
  }
}

export function downloadDatabaseBackup(payload: DatabaseBackupPayload): boolean {
  return downloadJsonFile(payload, `${payload.backupId}.json`);
}

export function downloadDynoRecordJSON(record: TestRecord): boolean {
  const certNo = record.certificateNumber || 'DYNO-RECORD';
  const safeSerial = (record.serialNumber || 'SN').replace(/[^a-zA-Z0-9-_]/g, '_');
  return downloadJsonFile(
    {
      schemaVersion: 1,
      exportedAt: new Date().toISOString(),
      certificate: record,
    },
    `${certNo}_${safeSerial}_${record.overallResult}.json`
  );
}

export async function parseDatabaseBackup(file: File): Promise<DatabaseBackupPayload> {
  const parsed = JSON.parse(await file.text()) as Partial<DatabaseBackupPayload>;
  if (
    parsed.schemaVersion !== 1 ||
    parsed.application !== 'KRA Dyno Test & Quality Certificate System' ||
    !Array.isArray(parsed.users) ||
    !Array.isArray(parsed.products) ||
    !Array.isArray(parsed.parameterLibrary) ||
    !Array.isArray(parsed.testRecords) ||
    !Array.isArray(parsed.auditLogs)
  ) {
    throw new Error('The selected file is not a valid KRA Dyno database backup.');
  }
  return parsed as DatabaseBackupPayload;
}
