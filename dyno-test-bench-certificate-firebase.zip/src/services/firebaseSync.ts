import { getApp, getApps, initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDocs,
  getFirestore,
  onSnapshot,
  setDoc,
  Unsubscribe,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

export type CloudDatasetName =
  | 'users'
  | 'products'
  | 'parameterLibrary'
  | 'testRecords'
  | 'auditLogs';

export type CloudConnectionState =
  | 'CONNECTING'
  | 'SYNCED'
  | 'LOCAL_ONLY'
  | 'ERROR';

export interface CloudSyncInfo {
  state: CloudConnectionState;
  message: string;
  lastSyncedAt?: string;
  anonymousUid?: string;
}

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const ORGANIZATION_ID = 'kra-development';

let authenticationPromise: Promise<string> | null = null;

function removeUndefined(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map(removeUndefined);
  }

  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>)
        .filter(([, child]) => child !== undefined)
        .map(([key, child]) => [key, removeUndefined(child)])
    );
  }

  return value;
}

function datasetCollection(dataset: CloudDatasetName) {
  return collection(db, 'organizations', ORGANIZATION_ID, dataset);
}

/**
 * Development-only Firebase identity. Enable Anonymous Authentication in the
 * Firebase console before publishing this build. Replace this with managed
 * employee authentication before production use.
 */
export async function ensureDevelopmentFirebaseAuth(): Promise<string> {
  if (auth.currentUser) return auth.currentUser.uid;

  if (!authenticationPromise) {
    authenticationPromise = signInAnonymously(auth)
      .then((credential) => credential.user.uid)
      .catch((error) => {
        authenticationPromise = null;
        throw error;
      });
  }

  return authenticationPromise;
}

export function subscribeToDataset<T extends { id: string }>(
  dataset: CloudDatasetName,
  onData: (items: T[]) => void,
  onError: (error: Error) => void
): Unsubscribe {
  return onSnapshot(
    datasetCollection(dataset),
    (snapshot) => {
      const items = snapshot.docs
        .map((snapshotDoc) => {
          const raw = snapshotDoc.data() as T & { __syncOrder?: number };
          const { __syncOrder = 0, ...item } = raw;
          return { item: item as T, order: __syncOrder };
        })
        .sort((a, b) => a.order - b.order)
        .map(({ item }) => item);

      onData(items);
    },
    (error) => onError(error)
  );
}

/**
 * Reconciles one small application dataset with Firestore. This development
 * implementation favors clarity and recovery over write minimization.
 */
export async function replaceDataset<T extends { id: string }>(
  dataset: CloudDatasetName,
  items: T[]
): Promise<void> {
  await ensureDevelopmentFirebaseAuth();

  const targetCollection = datasetCollection(dataset);
  const currentSnapshot = await getDocs(targetCollection);
  const targetIds = new Set(items.map((item) => item.id));

  await Promise.all(
    currentSnapshot.docs
      .filter((existing) => !targetIds.has(existing.id))
      .map((existing) => deleteDoc(existing.ref))
  );

  await Promise.all(
    items.map((item, index) =>
      setDoc(
        doc(targetCollection, item.id),
        removeUndefined({ ...item, __syncOrder: index }) as Record<string, unknown>
      )
    )
  );
}

export function cloudDataHash(value: unknown): string {
  return JSON.stringify(removeUndefined(value));
}
