import React, { useRef, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Cloud,
  Database,
  Download,
  HardDrive,
  RefreshCw,
  Upload,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  buildDatabaseBackup,
  downloadDatabaseBackup,
  parseDatabaseBackup,
} from '../services/dataBackup';

const LAST_BACKUP_KEY = 'kra_last_downloaded_backup';

export const DataBackupRestore: React.FC = () => {
  const {
    users,
    products,
    parameterLibrary,
    testRecords,
    auditLogs,
    testBenches,
    currentUser,
    cloudSyncInfo,
    syncCloudNow,
    restoreDatabase,
    logAudit,
  } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [lastBackupAt, setLastBackupAt] = useState<string | null>(() =>
    localStorage.getItem(LAST_BACKUP_KEY)
  );

  const downloadBackup = () => {
    const payload = buildDatabaseBackup({
      users,
      products,
      parameterLibrary,
      testRecords,
      auditLogs,
      testBenches,
    });
    if (!downloadDatabaseBackup(payload)) {
      setNotice({ type: 'error', text: 'Backup file could not be downloaded.' });
      return;
    }
    localStorage.setItem(LAST_BACKUP_KEY, payload.createdAt);
    setLastBackupAt(payload.createdAt);
    logAudit(
      'DATABASE_BACKUP_DOWNLOADED',
      `Downloaded complete database backup ${payload.backupId}.`
    );
    setNotice({ type: 'success', text: `Backup ${payload.backupId} downloaded successfully.` });
  };

  const runCloudSync = async () => {
    setBusy(true);
    const success = await syncCloudNow();
    setBusy(false);
    setNotice({
      type: success ? 'success' : 'error',
      text: success
        ? 'Firebase synchronization completed.'
        : 'Firebase synchronization failed. Your local data is still available.',
    });
  };

  const restoreBackup = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;

    try {
      const payload = await parseDatabaseBackup(file);
      const confirmed = window.confirm(
        `Restore ${payload.testRecords.length} test records, ${payload.products.length} products, and ${payload.users.length} users from ${payload.backupId}? This will replace the current shared datasets.`
      );
      if (!confirmed) return;

      restoreDatabase(payload);
      logAudit(
        'DATABASE_BACKUP_RESTORED',
        `Restored complete database backup ${payload.backupId}.`
      );
      setNotice({
        type: 'success',
        text: `Backup ${payload.backupId} restored. Firebase synchronization will follow automatically.`,
      });
    } catch (error) {
      setNotice({
        type: 'error',
        text: error instanceof Error ? error.message : 'Backup restore failed.',
      });
    }
  };

  const statusColor =
    cloudSyncInfo.state === 'SYNCED'
      ? 'text-emerald-700 bg-emerald-50 border-emerald-200'
      : cloudSyncInfo.state === 'CONNECTING'
      ? 'text-blue-700 bg-blue-50 border-blue-200'
      : 'text-amber-800 bg-amber-50 border-amber-200';

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6">
        <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-5">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-blue-950 text-white flex items-center justify-center shrink-0">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Firebase Cloud Sync & Data Backup</h2>
              <p className="text-sm text-slate-600 mt-1 max-w-2xl">
                Firestore keeps shared application data synchronized between computers. The browser cache remains available as a fallback, while downloadable JSON backups provide an independent recovery copy.
              </p>
            </div>
          </div>
          <div className={`px-3 py-2 rounded-lg border text-xs font-semibold ${statusColor}`}>
            <div className="flex items-center gap-2">
              {cloudSyncInfo.state === 'SYNCED' ? (
                <CheckCircle2 className="w-4 h-4" />
              ) : cloudSyncInfo.state === 'CONNECTING' ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <AlertTriangle className="w-4 h-4" />
              )}
              {cloudSyncInfo.state.replace('_', ' ')}
            </div>
          </div>
        </div>
      </div>

      {notice && (
        <div className={`rounded-xl border px-4 py-3 text-sm font-medium ${notice.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-rose-50 border-rose-200 text-rose-800'}`}>
          {notice.text}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <section className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center gap-3 mb-4">
            <Cloud className="w-5 h-5 text-blue-700" />
            <div>
              <h3 className="font-bold text-slate-900">Shared Firebase Database</h3>
              <p className="text-xs text-slate-500">Realtime synchronization for all development computers</p>
            </div>
          </div>
          <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 text-xs text-slate-700 min-h-20">
            <p className="font-semibold">{cloudSyncInfo.message}</p>
            <p className="mt-2 text-slate-500">
              Last synchronized:{' '}
              {cloudSyncInfo.lastSyncedAt
                ? new Date(cloudSyncInfo.lastSyncedAt).toLocaleString()
                : 'Not yet synchronized'}
            </p>
          </div>
          <button
            type="button"
            onClick={runCloudSync}
            disabled={busy}
            className="mt-4 w-full px-4 py-2.5 rounded-lg bg-blue-950 hover:bg-blue-900 text-white text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-60"
          >
            <RefreshCw className={`w-4 h-4 ${busy ? 'animate-spin' : ''}`} />
            Synchronize Now
          </button>
        </section>

        <section className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center gap-3 mb-4">
            <HardDrive className="w-5 h-5 text-amber-600" />
            <div>
              <h3 className="font-bold text-slate-900">Independent JSON Backup</h3>
              <p className="text-xs text-slate-500">Recovery copy outside the browser and Firebase</p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center mb-4">
            <div className="rounded-lg bg-slate-50 border border-slate-200 p-2">
              <strong className="block text-lg text-slate-900">{testRecords.length}</strong>
              <span className="text-[10px] text-slate-500">Test Records</span>
            </div>
            <div className="rounded-lg bg-slate-50 border border-slate-200 p-2">
              <strong className="block text-lg text-slate-900">{products.length}</strong>
              <span className="text-[10px] text-slate-500">Products</span>
            </div>
            <div className="rounded-lg bg-slate-50 border border-slate-200 p-2">
              <strong className="block text-lg text-slate-900">{auditLogs.length}</strong>
              <span className="text-[10px] text-slate-500">Audit Events</span>
            </div>
          </div>
          <p className="text-xs text-slate-500 mb-3">
            Last downloaded backup:{' '}
            {lastBackupAt ? new Date(lastBackupAt).toLocaleString() : 'No backup downloaded yet'}
          </p>
          <div className="flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              onClick={downloadBackup}
              className="flex-1 px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-sm font-bold flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" /> Download Full Backup
            </button>
            {currentUser?.role === 'ADMIN' && (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 px-4 py-2.5 rounded-lg border border-slate-300 hover:bg-slate-50 text-slate-800 text-sm font-bold flex items-center justify-center gap-2"
              >
                <Upload className="w-4 h-4" /> Restore Backup
              </button>
            )}
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/json,.json"
            className="hidden"
            onChange={restoreBackup}
          />
        </section>
      </div>

      <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900 flex items-start gap-2">
        <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
        <p>
          Development mode uses Firebase Anonymous Authentication. Before production release, replace it with managed employee authentication and role-based Firestore Security Rules.
        </p>
      </div>
    </div>
  );
};
