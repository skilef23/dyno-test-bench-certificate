import React from 'react';

interface KomatsuLogoProps {
  className?: string;
  variant?: 'full' | 'dark' | 'white' | 'badge';
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

/**
 * Official Komatsu Reman Logo Component
 * Matches the uploaded KRA Reman logo precisely:
 * 1. KOMATSU: Official brand vector geometry in royal blue (#000EB4)
 * 2. Reman: Exact font typography (Arial / Helvetica Bold) with soft drop shadow centered under the brandmark
 */
export const KomatsuLogo: React.FC<KomatsuLogoProps> = ({
  className = '',
  variant = 'full',
  size = 'md',
}) => {
  const isWhite = variant === 'white';
  const isDark = variant === 'dark';
  const isBadge = variant === 'badge';

  // Exact Komatsu Brand Colors matching the uploaded image
  const komatsuColor = isWhite ? '#FFFFFF' : '#000EB4';
  const remanColor = isWhite ? '#F8FAFC' : isDark ? '#FFFFFF' : '#000000';

  // Size presets
  const sizeClasses = {
    sm: 'h-7',
    md: 'h-10',
    lg: 'h-14',
    xl: 'h-20',
  }[size];

  const svgContent = (
    <svg
      viewBox="0 0 170 78"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="w-full h-full select-none"
      aria-label="Komatsu Reman Logo"
    >
      <defs>
        {/* Soft shadow filter for the Reman typography matching the user's image */}
        <filter id="reman-drop-shadow" x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0" dy="1.2" stdDeviation="1.2" floodColor="#000000" floodOpacity={isWhite ? '0' : '0.35'} />
        </filter>
      </defs>

      {/* Official KOMATSU Logotype Vector Path */}
      <path
        d="M159 33.2c-2.9.1-5.7-.7-7.9-2.5-2.1-1.9-3.2-4.6-3-7.4v-15h9.7v15c0 .7.6 1.3 1.3 1.3.7 0 1.2-.6 1.3-1.3v-15h9.7v15c0 3.2-1 5.7-3 7.4-2.4 1.8-5.3 2.7-8.1 2.5zm-121.3 0c-7-.1-12.7-5.8-12.6-12.9-.2-7 5.4-12.8 12.4-12.9 7-.2 12.8 5.4 12.9 12.4v.6c0 3.4-1.3 6.7-3.7 9.1-2.4 2.4-5.6 3.7-9 3.7zm0-16.5c-2 0-3.7 1.6-3.7 3.6s1.6 3.7 3.6 3.7 3.7-1.6 3.7-3.6v-.1c0-2-1.6-3.6-3.6-3.6zm97.6 16.5c-4.1 0-6.9-1.2-10.4-3.2l2.7-6.4s4 2.6 6.7 2.6c.3 0 .6 0 .9-.1.5-.1.8-.5.8-1s-.2-.9-.7-1.1c-.5-.2-1.1-.4-1.6-.5-1.9-.5-4.9-1.2-6.4-4.1-1.7-3.2-1-7.1 1.7-9.4 2.1-1.7 4.7-2.6 7.4-2.6h.5c3 .1 5.9 1 8.5 2.7l-2.7 6.4c-1.8-1-4.2-2.1-5.7-2.1-.8 0-1.2.3-1.3.9-.1.9.8 1.2 2.3 1.6 1.3.3 2.5.7 3.7 1.3 2.9 1.7 4.4 5.1 3.5 8.4-.4 1.9-1.5 3.5-3.1 4.6-1.9 1.4-4.3 2.1-6.8 2zM9.8 32.3H0V8.4h9.8V20L15 8.4h11.1l-5.6 11.7 5.9 12.2H15.3L9.8 20.1v12.2zm50 0H51l3.6-23.9h8.9l3 9.6 3-9.6h8.9l3.3 22.5 7.6-22.5H99l8.2 23.9H97L94.1 21l-2.9 11.3H73l-1.3-9.1-2.5 9.1h-5.7L61 23.2l-1.2 9.1zm60 0H110v-15h-5.7V8.4h15.4V.8h9.1v9.5h-9.1l.1 22z"
        fill={komatsuColor}
      />

      {/* Exact 'Reman' text with font family, weight, kerning, and soft shadow matching the uploaded image */}
      <text
        x="85"
        y="65"
        textAnchor="middle"
        fill={remanColor}
        fontFamily="Arial, 'Helvetica Neue', Helvetica, -apple-system, sans-serif"
        fontWeight="800"
        fontSize="30"
        letterSpacing="-0.02em"
        filter="url(#reman-drop-shadow)"
      >
        Reman
      </text>
    </svg>
  );

  if (isBadge) {
    return (
      <div
        className={`inline-flex items-center justify-center bg-white rounded-lg px-2.5 py-1 border border-slate-200 shadow-xs ${sizeClasses} ${className}`}
      >
        {svgContent}
      </div>
    );
  }

  return (
    <div className={`inline-flex items-center justify-center ${sizeClasses} ${className}`}>
      {svgContent}
    </div>
  );
};
